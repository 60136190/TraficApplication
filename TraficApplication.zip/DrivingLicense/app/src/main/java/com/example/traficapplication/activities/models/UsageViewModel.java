package com.example.traficapplication.activities.models;

public class UsageViewModel {
}
