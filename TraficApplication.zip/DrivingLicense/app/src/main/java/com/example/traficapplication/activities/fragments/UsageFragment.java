package com.example.traficapplication.activities.fragments;

public class UsageFragment {
}
