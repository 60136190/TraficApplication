package com.example.traficapplication.activities.models;

public class SettingViewModel {
}
